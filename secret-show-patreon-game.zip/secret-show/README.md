
# Secret Show - Patreon-Gated Ren'Py Game

## Backend Setup (Flask)

### To run locally or deploy to Render/Railway:

1. Install dependencies:

    pip install -r requirements.txt

2. Rename `.env.template` to `.env` and fill in your credentials.

3. Run:

    flask run

## Patreon Setup

- Register your app at https://www.patreon.com/portal/registration/register-clients
- Use the `/callback` route as your Redirect URI.

## Deploy to Railway

1. Go to https://railway.app/
2. Create a new project → Deploy from GitHub or upload this server folder
3. Add your environment variables to Railway's settings.
4. Click "Deploy"

