
from flask import Flask, request, redirect, jsonify
import os
import boto3
import requests
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

CLIENT_ID = os.getenv("PATREON_CLIENT_ID")
CLIENT_SECRET = os.getenv("PATREON_CLIENT_SECRET")
REDIRECT_URI = os.getenv("PATREON_REDIRECT_URI")
S3_BUCKET = os.getenv("S3_BUCKET")
AWS_KEY = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET = os.getenv("AWS_SECRET_ACCESS_KEY")

@app.route("/callback")
def patreon_callback():
    code = request.args.get("code")
    token_res = requests.post(
        "https://www.patreon.com/api/oauth2/token",
        data={
            "code": code,
            "grant_type": "authorization_code",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "redirect_uri": REDIRECT_URI,
        }
    ).json()

    access_token = token_res.get("access_token")
    return redirect(f"https://yourgame.com?token={access_token}")

@app.route("/verify")
def verify():
    token = request.args.get("token")
    headers = {"Authorization": f"Bearer {token}"}
    user_res = requests.get("https://www.patreon.com/api/oauth2/v2/identity?include=memberships", headers=headers)
    
    data = user_res.json()
    try:
        tiers = data["included"][0]["attributes"]["patron_status"]
        if tiers == "active_patron":
            s3 = boto3.client("s3",
                aws_access_key_id=AWS_KEY,
                aws_secret_access_key=AWS_SECRET
            )
            presigned_url = s3.generate_presigned_url(
                'get_object',
                Params={'Bucket': S3_BUCKET, 'Key': 'secret.mp4'},
                ExpiresIn=3600
            )
            return jsonify({"access": True, "video_url": presigned_url})
    except:
        pass
    return jsonify({"access": False})
